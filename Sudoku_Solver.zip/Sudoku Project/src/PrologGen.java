
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;

import org.jpl7.Query;
import org.jpl7.Term;

public class PrologGen {
	public static int[][] grid;
	public static display dis;

	public static void main(String[] args) {
		dis = new display();

	}

	public static void Solve(String x) {

		grid = new int[9][9];

		int p = 0;
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				grid[i][j] = Integer.parseInt(x.charAt(p++) + "");
			}
		}

		String y = "";
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				if (grid[i][j] != 0) {
					y += (char) ('A' + i) + "" + (j + 1) + "#=" + grid[i][j] + ",\n";
				}
			}
		}
		String writer = ":- use_module(library(clpfd)).\r\n" + "sudoku(L):-\r\n"
				+ "	L=[A1,A2,A3,A4,A5,A6,A7,A8,A9,B1,B2,B3,B4,B5,B6,B7,B8,B9,C1,C2,C3,C4,C5,C6,C7,C8,C9,D1,D2,D3,D4,D5,D6,D7,D8,D9,E1,E2,E3,E4,E5,E6,E7,E8,E9,F1,F2,F3,F4,F5,F6,F7,F8,F9,G1,G2,G3,G4,G5,G6,G7,G8,G9,H1,H2,H3,H4,H5,H6,H7,H8,H9,I1,I2,I3,I4,I5,I6,I7,I8,I9],\r\n"
				+ "	L ins 1..9,";
		writer += y;
		writer += "all_distinct([A1,A2,A3,A4,A5,A6,A7,A8,A9]),\r\n" + "	all_distinct([B1,B2,B3,B4,B5,B6,B7,B8,B9]),\r\n"
				+ "	all_distinct([C1,C2,C3,C4,C5,C6,C7,C8,C9]),\r\n"
				+ "	all_distinct([D1,D2,D3,D4,D5,D6,D7,D8,D9]),\r\n"
				+ "	all_distinct([E1,E2,E3,E4,E5,E6,E7,E8,E9]),\r\n"
				+ "	all_distinct([F1,F2,F3,F4,F5,F6,F7,F8,F9]),\r\n"
				+ "	all_distinct([G1,G2,G3,G4,G5,G6,G7,G8,G9]),\r\n"
				+ "	all_distinct([H1,H2,H3,H4,H5,H6,H7,H8,H9]),\r\n"
				+ "	all_distinct([I1,I2,I3,I4,I5,I6,I7,I8,I9]),\r\n"
				+ "	all_distinct([A1,B1,C1,D1,E1,F1,G1,H1,I1]),\r\n"
				+ "	all_distinct([A2,B2,C2,D2,E2,F2,G2,H2,I2]),\r\n"
				+ "	all_distinct([A3,B3,C3,D3,E3,F3,G3,H3,I3]),\r\n"
				+ "	all_distinct([A4,B4,C4,D4,E4,F4,G4,H4,I4]),\r\n"
				+ "	all_distinct([A5,B5,C5,D5,E5,F5,G5,H5,I5]),\r\n"
				+ "	all_distinct([A6,B6,C6,D6,E6,F6,G6,H6,I6]),\r\n"
				+ "	all_distinct([A7,B7,C7,D7,E7,F7,G7,H7,I7]),\r\n"
				+ "	all_distinct([A8,B8,C8,D8,E8,F8,G8,H8,I8]),\r\n"
				+ "	all_distinct([A9,B9,C9,D9,E9,F9,G9,H9,I9]),\r\n"
				+ "	all_distinct([A1,A2,A3,B1,B2,B3,C1,C2,C3]),\r\n"
				+ "	all_distinct([A4,A5,A6,B4,B5,B6,C4,C5,C6]),\r\n"
				+ "	all_distinct([A7,A8,A9,B7,B8,B9,C7,C8,C9]),\r\n"
				+ "	all_distinct([D1,D2,D3,E1,E2,E3,F1,F2,F3]),\r\n"
				+ "	all_distinct([D4,D5,D6,E4,E5,E6,F4,F5,F6]),\r\n"
				+ "	all_distinct([D7,D8,D9,E7,E8,E9,F7,F8,F9]),\r\n"
				+ "	all_distinct([G1,G2,G3,H1,H2,H3,I1,I2,I3]),\r\n"
				+ "	all_distinct([G4,G5,G6,H4,H5,H6,I4,I5,I6]),\r\n"
				+ "	all_distinct([G7,G8,G9,H7,H8,H9,I7,I8,I9]),\r\n" + "	labeling([],L).";

		try {
			String directory="D:\\My Projects\\Sudoku";
			File dir = new File(directory);

			File[] matches = dir.listFiles(new FilenameFilter()
			{
			  public boolean accept(File dir, String name)
			  {
			     return name.startsWith("sudoku") && name.endsWith(".pl");
			  }
			});
			
			
			FileWriter fw = new FileWriter(matches[0]);
			fw.write(writer);
			fw.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		String t1 = "consult('sudoku.pl')";
		System.out.println(t1 + " " + (Query.hasSolution(t1) ? "succeeded" : "failed"));

		String sol = "";
		Query q = new Query("sudoku(L)");
		System.out.println(q.oneSolution());
		for (Term t : q.oneSolution().get("L").toTermArray()) {

			sol += t;
		}
		System.out.println(sol);
		dis.disp(sol);
	}

}
