import javax.swing.JButton;

public class selB extends JButton{
public selB() {
	super();
}
}
