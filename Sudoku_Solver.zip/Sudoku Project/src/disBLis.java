import java.awt.event.ActionListener;

public interface disBLis extends ActionListener{

}
