import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class display extends JFrame {
	public static int selI = 0;
	public static disB[] v;
	public static ActionListener selA;
	public static ActionListener disA;
	public static ActionListener solA;
	public static int[][] grid;

	public display() {
		super("SUDOKU");

		v = new disB[9 * 9];

		Font font=new Font("TimesRoman", Font.PLAIN, 30);
		setSize(500, 650);

		setVisible(true);
		JButton solve = new JButton("SOLVE");
		solA = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				getNums();

			}

		};
		solve.addActionListener(solA);

		selA = (new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				selI = Integer.parseInt(((JButton) (arg0.getSource())).getText());
				System.out.println(selI);

			}

		});
		
		JPanel selP = new JPanel();
		selP.setPreferredSize(new Dimension(500, 100));
		selP.setLayout(new GridLayout(2, 4));
		Dimension dim = new Dimension(100, 50);
		for (int i = 0; i <= 9; i++) {
			selB b = new selB();
			b.setText(i + "");
			b.setFont(font);
			b.setPreferredSize(dim);

			b.addActionListener(selA);
			selP.add(b);
		}
		JPanel disP = new JPanel();
		disP.setLayout(new GridLayout(9, 9));

		disA = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				((JButton) (arg0.getSource())).setText(selI + "");

			}

		};
		setDefaultCloseOperation(2);
		for (int j = 0; j < 9 * 9; j++) {
			disB bn = new disB();
			bn.setText(0 + "");
			bn.setBackground(Color.WHITE);
			bn.addActionListener(disA);
			bn.setFont(font);
			disP.add(bn);
			v[j] = bn;
		}
		JPanel nor = new JPanel();
		nor.setLayout(new GridLayout(1, 2));
		nor.add(solve);

		setLayout(new BorderLayout());
		add(selP, BorderLayout.SOUTH);
		add(disP, BorderLayout.CENTER);
		add(nor, BorderLayout.NORTH);
		repaint();
		revalidate();

	}
	public void getNums() {
		String x="";
		for(disB b:v) {
			x+=b.getText();
		}
		PrologGen.Solve(x);
	}
	
	public void disp(String x) {
		for(int i=0;i<9*9;i++) {
			v[i].setText(x.charAt(i)+"");
		}
		revalidate();
		repaint();
	}
	

}
