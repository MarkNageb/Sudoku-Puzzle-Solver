import java.awt.event.ActionListener;

public interface selBLis extends ActionListener{

}
