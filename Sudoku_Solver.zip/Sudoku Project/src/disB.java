import javax.swing.JButton;

public class disB extends JButton{
	public disB() {
		super();
	}
}
